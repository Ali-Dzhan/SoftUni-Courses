package sharkHaunt;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public class Basin {
    private String name;
    private int capacity;
    private List<Shark> sharks;

    public Basin(String name, int capacity) {
        this.name = name;
        this.capacity = capacity;
        this.sharks = new ArrayList<>();

    }

    public void addShark(Shark shark){
        if (sharks.stream().anyMatch(s -> s.getKind().equals(shark.getKind()) || s.getLength() == shark.getLength())) {
            throw new IllegalArgumentException("sharkHaunt.Shark with the same kind or length already exists in the basin.");
        }
        if(capacity > sharks.size()){
            sharks.add(shark);
        } else {
            System.out.println("This basin is at full capacity!");
        }
    }

    //Method removeShark(String kind) – removes a shark by given kind,
    // if such exists, and returns boolean (true if it is removed, otherwise – false)

    public boolean removeShark(String kind){
        for (Shark shark : sharks) {
            if(shark.getKind().equals(kind)){
                sharks.remove(shark);
                return  true;
            }

        }
        return false;
    }

    public Shark getLargestShark(){

        return sharks.stream().max(Comparator.comparingInt(Shark::getLength)).orElse(null);
    }

    public Shark getShark(String kind){
        for (Shark shark : sharks) {
            if(shark.getKind().equals(kind)){
                return shark;
            }
        }
        return null;
    }

    public int getCount(){
        return sharks.size();
    }

    public String report(){
        System.out.printf("Sharks in %s:\n",name);

        StringBuilder sb = new StringBuilder();
        for (Shark s : sharks) {
            sb.append(s.toString()).append(System.lineSeparator());
        }
        return sb.toString();
    }

    public int getAverageLength(){
        int sum =0;
        for (Shark shark : sharks) {
            sum += shark.getLength();
        }
        return sum / sharks.size();
    }

}


