public interface Vehicles {
    String drive(Double distance);
    void refuel(Double litters);
}
