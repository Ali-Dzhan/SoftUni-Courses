import java.math.BigDecimal;

public class ColdBeverage extends Beverage{
    public ColdBeverage(String name, BigDecimal price, double millilitres){
        super(name, price, millilitres);
    }
}
