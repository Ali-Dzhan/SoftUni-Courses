public class Dog extends Animal{

    public static void bark(){
        System.out.println("barking...");
    }

}

