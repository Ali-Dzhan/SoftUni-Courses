public class Animal {
    public static void eat(){
        System.out.println("eating...");
    }
}
