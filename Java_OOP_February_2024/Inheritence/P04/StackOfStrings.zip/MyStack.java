import java.util.ArrayDeque;

public class MyStack extends ArrayDeque<String> {
}
