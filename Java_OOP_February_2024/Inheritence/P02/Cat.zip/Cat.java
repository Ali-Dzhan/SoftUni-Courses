public class Cat extends Animal{
    public  static void meow(){
        System.out.println("meowing...");
    }
}
