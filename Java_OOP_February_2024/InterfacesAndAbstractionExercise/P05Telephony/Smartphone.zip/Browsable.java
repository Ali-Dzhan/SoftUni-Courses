import java.util.List;

public interface Browsable {
    String browse();
}
