import java.util.List;

public interface Callable {

    String call();
}
