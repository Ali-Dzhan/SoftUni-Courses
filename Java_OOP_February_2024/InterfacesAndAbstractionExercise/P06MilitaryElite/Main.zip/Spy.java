public interface Spy {
    String getCodeNumber();
}
