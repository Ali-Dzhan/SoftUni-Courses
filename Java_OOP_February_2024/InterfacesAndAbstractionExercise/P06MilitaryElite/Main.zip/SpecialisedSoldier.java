public interface SpecialisedSoldier extends Private{
    Corps getCorp();
}
