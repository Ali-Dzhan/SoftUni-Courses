public interface Repair {
    String getPartName();

    int getWorkedHours();
}
