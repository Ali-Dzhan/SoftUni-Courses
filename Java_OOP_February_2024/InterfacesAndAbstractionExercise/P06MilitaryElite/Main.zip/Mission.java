public interface Mission {
    String getCodeName();

    Status getState();
}
