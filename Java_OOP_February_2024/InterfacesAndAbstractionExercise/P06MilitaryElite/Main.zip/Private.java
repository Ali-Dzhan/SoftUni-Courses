public interface Private {
    Double getSalary();
}
