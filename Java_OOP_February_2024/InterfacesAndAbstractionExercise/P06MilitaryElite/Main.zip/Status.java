public enum Status {
    inProgress,
    finished;
}
